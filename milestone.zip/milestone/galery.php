<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-navbarku">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="logo.png" alt="" height="30">      
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link " href="index.php">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                        <li class="nav-item"><a class="nav-link" href="purchase.php">PRODUCTS</a></li>
                        <li class="nav-item"><a class="nav-link" href="galery.php">GALLERY</a></li>
                        <li class="nav-item"><a class="nav-link" href="aboutus.php">ABOUT US</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT US</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section class="gallery-banner">
        <img src="locker.jpg" alt="background">
    </section>
    <section class="top-selling py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="product-card">
                        <img src="jersey 5.jpeg" alt="Product 1">
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="product-card">
                        <img src="jersey 2.jpeg" alt="Product 2">
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="product-card">
                        <img src="jersey 3.jpeg" alt="Product 3">
                    </div>
                </div>
    </section>
    <section class="gallery-container">
        <h2>Customer Review</h2>
        <div class="reviews">
            <div class="review">
                <p>" Jersey Original, Packing rapi Keren oi"</p>
                <span>- Rusdi</span>
            </div>
            <div class="review">
                <p>" Siap menerjang suporter lawan dan bapak kamu"</p>
                <span>- Yadi</span>
            </div>
            <div class="review">
                <p>" Jersey Original. Admin gamtenk"</p>
                <span>- Yudi</span>
            </div>
        </div>
    </section>
    <section class="gallery-container">
        <div class="reviews">
            <div class="review">
                <p>" uwowwwwwwwwwww, SHB!!"</p>
                <span>- nguyen</span>
            </div>
            <div class="review">
                <p>" Packing Rapi, koleksi jersey langka"</p>
                <span>- Didi</span>
            </div>
            <div class="review">
                <p>" aku suka deh, keren bat oi oi"</p>
                <span>- Udin</span>
            </div>
        </div>
    </section>
    <section class="gallery-container">
        <div class="reviews">
            <div class="review">
                <p>" Unexpected, Melebihi ekpetasi bapak"</p>
                <span>- mas Anies</span>
            </div>
            <div class="review">
                <p>" ini review, jersey bagus ya"</p>
                <span>- Heri</span>
            </div>
            <div class="review">
                <p>" Harga bagus, diskon lagi Punk OI,Oi"</p>
                <span>- Mat Pertamina</span>
            </div>
        </div>
    </section>
    <footer class="bg-light p-3">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <p class="mb-0">Follow us on Instagram @kangjersey </p>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>