<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_POST['add_to_cart'])) {
    $name = $_POST['product_name'];
    $price = $_POST['product_price'];
    $image = $_POST['product_image'];

    $item = [
        'name' => $name,
        'price' => $price,
        'image' => $image,
        'quantity' => 1
    ];

    $found = false;
    foreach ($_SESSION['cart'] as &$cartItem) {
        if ($cartItem['name'] == $name) {
            $cartItem['quantity']++;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $_SESSION['cart'][] = $item;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body> 
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-navbarku">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="logo.png" alt="" height="30">      
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link " href="index.php">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                        <li class="nav-item"><a class="nav-link" href="purchase.php">PRODUCTS</a></li>
                        <li class="nav-item"><a class="nav-link" href="galery.php">GALLERY</a></li>
                        <li class="nav-item"><a class="nav-link" href="aboutus.php">ABOUT US</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT US</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <section class="top-selling py-5">
            <div class="container">
                <h2 class="text-center mb-4">Our Product</h2>
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 1.jpeg" alt="Product 1">
                            <h5>Jersey Home Persebaya</h5>
                            <p class="price">Rp 399.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Home-Persebaya">
                                <input type="hidden" name="product_price" value="399000">
                                <input type="hidden" name="product_image" value="jersey 1.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 2.jpeg" alt="Product 2">
                            <h5>Jersey Away Persebaya</h5>
                            <p class="price">Rp 399.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Away-Persebaya">
                                <input type="hidden" name="product_price" value="399000">
                                <input type="hidden" name="product_image" value="jersey 2.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 3.jpeg" alt="Product 3">
                            <h5>Jersey Home Willem II</h5>
                            <p class="price">Rp 799.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Home-Willem II">
                                <input type="hidden" name="product_price" value="799000">
                                <input type="hidden" name="product_image" value="jersey 3.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 4.jpeg" alt="Product 4">
                            <h5>Jersey Away Burnley</h5>
                            <p class="price">Rp 1.399.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Away-Burnley">
                                <input type="hidden" name="product_price" value="1399000">
                                <input type="hidden" name="product_image" value="jersey 4.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 5.jpeg" alt="Product 5">
                            <h5>Jersey Home SHB Da Nang</h5>
                            <p class="price">Rp 599.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Home-SHB">
                                <input type="hidden" name="product_price" value="599000">
                                <input type="hidden" name="product_image" value="jersey 5.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="sepatu 1.jpeg" alt="Product 6">
                            <h5>Adidas Predator</h5>
                            <p class="price">Rp 2.599.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Adidas-Predator">
                                <input type="hidden" name="product_price" value="2599000">
                                <input type="hidden" name="product_image" value="sepatu 1.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="sepatu 2.jpeg" alt="Product 7">
                            <h5>Nike Air Max 9</h5>
                            <p class="price">Rp 2.999.000</p>
                            <form method="post">
                                <input type="hidden" name="product_name" value="Nike-Air">
                                <input type="hidden" name="product_price" value="2999000">
                                <input type="hidden" name="product_image" value="sepatu 2.jpeg">
                                <button type="submit" name="add_to_cart" class="add-to-cart">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                    <div class="checkout">
                        <a href="checkout.php">
                            <button class="checkout-btn">Go to Checkout</button>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <footer class="bg-light p-3">
            <div class="container d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-0">Follow us on Instagram @kangjersey </p>
                </div>
            </div>
        </footer>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>