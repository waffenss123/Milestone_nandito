<?php
require_once 'conn.php';
print_r($_POST);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (empty($password)) {
        echo "Password tidak boleh kosong.";
    } else {

        $sql = "INSERT INTO users (firstName, lastName, username, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $firstName, $lastName, $username, $password);

        if ($stmt->execute()) {
            echo "Registrasi berhasil!";
            header("Location: login.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>