<?php
session_start();
include 'conn.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: purchase.php');
    exit();
}

$totalPrice = 0;
foreach ($_SESSION['cart'] as $item) {
    $totalPrice += $item['price'] * $item['quantity'];
}

$discount = $totalPrice * 0.05;
$finalTotal = $totalPrice - $discount;

if (isset($_POST['checkout'])) {
    $customerName = $_POST['customer_name'];
    $customerPhone = $_POST['customer_phone'];
    $customerAddress = $_POST['customer_address'];

    if (!empty($customerName) && !empty($customerPhone) && !empty($customerAddress)) {
        $detailPesanan = json_encode($_SESSION['cart']);

        $sql = "INSERT INTO pesanan (nama_pelanggan, nomor_telepon, alamat_pengiriman, total_harga, detail_pesanan) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $customerName, $customerPhone, $customerAddress, $finalTotal, $detailPesanan);

        if ($stmt->execute()) {
            unset($_SESSION['cart']);
            echo "<script>alert('Pesanan Berhasil Dibuat! Terima kasih telah berbelanja.'); window.location.href = 'index.php';</script>";
            exit();
        } else {
            echo "<script>alert('Terjadi kesalahan saat memproses pesanan: " . $conn->error . "');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Silakan isi nama, nomor, dan alamat pengiriman.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="co.css">
</head>
<body onload="displayCart()">
<section class="top-selling py-5">
            <div class="container-co">
                <h2 class="text-center mb-4">Checkout</h2>
                <div class="row">
                    <div class="col-md-8">
                        <h3>Keranjang Belanja</h3>
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Gambar</th>
                                        <th>Nama Produk</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($_SESSION['cart'] as $item): ?>
                                        <tr>
                                            <td><img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" style="width: 50px;"></td>
                                            <td><?php echo $item['name']; ?></td>
                                            <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p>Keranjang Anda kosong.</p>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <h3>Ringkasan Pesanan</h3>
                        <p>Total Harga: Rp <?php echo number_format($totalPrice, 0, ',', '.'); ?></p>
                        <p>Diskon (5%): Rp <?php echo number_format($discount, 0, ',', '.'); ?></p>
                        <p><strong>Total Akhir: Rp <?php echo number_format($finalTotal, 0, ',', '.'); ?></strong></p>

                        <h3>Informasi Pembeli</h3>
                        <form method="post">
                            <div class="mb-3">
                                <label for="customer_name" class="form-label">Nama:</label>
                                <input type="text" name="customer_name" id="customer_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="customer_phone" class="form-label">Nomor Telepon:</label>
                                <input type="text" name="customer_phone" id="customer_phone" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="customer_address" class="form-label">Alamat:</label>
                                <textarea name="customer_address" id="customer_address" class="form-control" required></textarea>
                            </div>
                            <button type="submit" name="checkout" class="btn btn-primary">Checkout</button>
                            <a href="purchase.php" class="btn btn-secondary">Kembali</a>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script src="beli.js"></script>
</body>
</html>
