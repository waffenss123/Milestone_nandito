<?php
session_start();
if (!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football Community</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-navbarku">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="logo.png" alt="" height="30">     
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link " href="index.php">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                        <li class="nav-item"><a class="nav-link" href="purchase.php">PRODUCTS</a></li>
                        <li class="nav-item"><a class="nav-link" href="galery.php">GALLERY</a></li>
                        <li class="nav-item"><a class="nav-link" href="aboutus.php">ABOUT US</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT US</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <section class="banner">
            <img src="banner.png" alt="background">
        </section>
        <section>
            <div id="countdown" style="font-size: 24px; font-weight: bold; color: #8E1616; text-align: center; margin-top: 10px;"></div>
        </section>
        <section class="hero text-center py-5">
            <div class="container">
                <h1>Next Arrivals</h1>
                <img src="next arrivals.jpg" alt="move" class="img-fluid my-3">
            </div>  
        </section>
        <section class="top-selling py-5">
            <div class="container">
                <h2 class="text-center mb-4">Best Selling</h2>
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 5.jpeg" alt="Product 1">
                            <h5>Jersey Home SHB Da Nang</h5>
                            <p class="price">Rp 599.000</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 2.jpeg" alt="Product 1">
                            <h5>Jersey Away Persebaya</h5>
                            <p class="price">Rp 399.000</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="product-card">
                            <img src="jersey 3.jpeg" alt="Product 1">
                            <h5>Jersey Home Willem II</h5>
                            <p class="price">Rp 799.000</p>
                        </div>
                    </div>
                    <button type="button" class="btn btn-dark" onclick="location.href='purchase.html'">VIEW MORE</button>
        </section>
        <section class="news py-5">
            <h2 class="text-center mb-4">Berita Hari ini</h2>
            <div id="newsCarousel" class="carousel slide" data-bs-target="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="news1.jpeg" class="d-block w-100" alt="news1">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>PSIM Naik Kasta ke Liga 1 Musim Depan!</h5>
                        </div>
                    </div>
                    <div class="carousel-item active">
                        <img src="news2.jpeg" class="d-block w-100" alt="news1">
                        <div class="carousel-caption d-none d-md-block">
                            <h5>Persib hanya butuh konsistensi untuk juara</h5>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                </button>
            </div>
        </section> 
        <section class="py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="news5.jpeg" class="card-img-top" alt="news3">
                            <div class="card-body">
                                <h5 class="card-title">ADATASI TAKTIK LANCAR, HUISTRA...</h5>
                                <p class="card-text">FEBRUARY 27, 2025</p>
                                <p class="card-text">Skuad PSS Sleman menunjukkan peningkatan positif dalam memahami serta menerapkan instruksi pelatih. Hal itu diungkapkan Pelatih Kepala PSS Sleman Pieter Huistra...</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="NEWS4.jpeg" class="card-img-top" alt="news4">
                            <div class="card-body">
                                <h5 class="card-title">AKANKAH HANIIBAL EX-MANCHESTER UNITED BERMAIN DALAM...</h5>
                                <p class="card-text">FEBRUARY 28, 2025</p>
                                <p class="card-text">Celana chino rupanya masih menjadi opsi andalan bagi kaum pria untuk melengkapi style mereka sehari-hari, baik dalam acara formal maupun kasual. Terlebih, chino sendiri merupakan celana pria yang serbaguna dan....</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="news3.jpeg" class="card-img-top" alt="news5">
                            <div class="card-body">
                                <h5 class="card-title">JAIRO RIEDELWALD GAGAL NATURALISASI ...</h5>
                                <p class="card-text">FEBRUARY 19, 2025</p>
                                <p class="card-text">Ketua Umum PSSI, Erick Thohir mengatakan, Riedewald sejatinya welcome atau menyambut baik tawaran membela Timnas Indonesia. Namun, kendala ada di proses administrasi yakni berkas-berkas soal darah keturunannya.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="bg-light p-3">
            <div class="container d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-0">Follow us on Instagram @kangjersey </p>
                </div>
                <a href="login.php">Logout</a>
            </div>
        </footer>
    </main>
    <script src="index.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>