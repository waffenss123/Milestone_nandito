<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Football Community</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container-form">
        <div class="login-card">
        <h2>Register</h2>
        <form form id="registerForm" method="post" action="proses_register.php">
            <input type="text" name="firstName" placeholder="First Name" required>
            <input type="text" name="lastName" placeholder="Last Name" required>
            <input type="texk" name="username" placeholder="Masukan username" required>
            <input type="password" name="password" placeholder="Masukan Password" required>
            <button type="submit"> Register</button>
            <p>Already Have an account? <a href="login.php">Login Here</a></p>
        </form>
    </div>
    </div>
</body>
</html>
