<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JerseyKu - Tentang Kami</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-navbarku">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="logo.png" alt="" height="30">      
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link " href="index.php">HOME</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">LOGIN</a></li>
                        <li class="nav-item"><a class="nav-link" href="purchase.php">PRODUCTS</a></li>
                        <li class="nav-item"><a class="nav-link" href="galery.php">GALLERY</a></li>
                        <li class="nav-item"><a class="nav-link" href="aboutus.php">ABOUT US</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.php">CONTACT US</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section class="py-5">
        <div class="container">
            <h1 class="text-center mb-5">ABOUT US</h1>
            <div class="row">
                <div class="col-md-6">
                    <img src="aboutus.jpeg" alt="Tentang JerseyKu" class="img-fluid rounded mb-4">
                </div>
                <div class="col-md-6">
                    <h2>Misi Kami</h2>
                    <p>Kami hadir untuk memenuhi kebutuhan para penggemar olahraga, khususnya sepak bola, dengan menyediakan jersey berkualitas tinggi dari berbagai klub dan tim nasional di seluruh dunia. Kami percaya bahwa jersey bukan hanya sekadar pakaian, tetapi juga simbol kebanggaan dan semangat.</p>
                    <h2>Visi Kami</h2>
                    <p>Visi kami adalah menjadi toko jersey online terdepan di Indonesia, yang dikenal dengan koleksi lengkap, kualitas terbaik, dan pelayanan pelanggan yang memuaskan. Kami ingin menjadi tempat tujuan utama bagi para penggemar jersey untuk menemukan jersey impian mereka.</p>
                    <h2>Nilai-Nilai Kami</h2>
                    <ul>
                        <li>Kualitas: Kami hanya menyediakan jersey dengan kualitas terbaik, baik dari segi bahan maupun desain.</li>
                        <li>Koleksi Lengkap: Kami menawarkan koleksi jersey yang lengkap, mulai dari klub-klub besar Eropa hingga tim nasional dari berbagai negara.</li>
                        <li>Pelayanan Pelanggan: Kami selalu berusaha memberikan pelayanan terbaik kepada pelanggan, dengan respon cepat dan solusi yang memuaskan.</li>
                        <li>Keaslian: Kami menjamin keaslian setiap jersey yang kami jual.</li>
                    </ul>
                </div>
            </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>