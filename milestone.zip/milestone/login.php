<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="container-form">
        <div class="login-card">
        <h2>Login</h2>
        <form id="loginForm" method="post" action="proses_login.php"    >
            <input type="text" name="username" placeholder="Masukan username" required>
            <input type="password" name="password" placeholder="Masukan Password" required>
            <button type="submit"> Log In</button>
            <p>Don't Have an account? <a href="register.php">Register Here</a></p>
        </form>
        </div>
    </div>
</body>
</html>